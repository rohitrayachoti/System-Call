#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>

#define PORT 5984
#define BUFF_SIZE 4096

int main(int argc, const char *argv[])
{
	int sock = 0;
	struct sockaddr_in serv_addr;
	char *hello = "Hello from client";
	char buffer[BUFF_SIZE] = {0};

	/* [C1]
	 * The socket function call creates an endpoint for communication with the server.
	 * It takes the arguments domain, type and protocol.
	 * Domain specifies the communication domain in which the socket is to be created.
	 * Domain AF_INET indicates IPv4 Protocol.
	 * Type specifies the type of socket to be created.
	 * Type SOCK_STREAM provides sequential, bidirectional connection mode streams.
	 * Protocol value '0' represents the default protocol.
	 * It returns file descriptor on success, -1 on error.
	 */
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("\n Socket creation error \n");
		return -1;
	}

	/* [C2]
	 * memset allocates the memory and initialises serv_addr. 
	 * Assigning type and port to the server address object.
	 * AF_INET represents IPv4 Protocol and PORT is set to the object.  
	 */
	memset(&serv_addr, '0', sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(PORT);

	/* [C3]
	 * inet_pton function call converts ipaddress from text form to network address structure(IPv4 structure in this case).
	 * It stores the result in the last argument(serv_addr.sin_addr).
	 * It returns 1 on success, 0 if the ipaddress is not a valid network address, -1 if the first argument is not a valid address family.
	 */
	if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
		printf("\nInvalid address/ Address not supported \n");
		return -1;
	}

	/* [C4]
	 * The connect call connects the socket referred to by the file descriptor sock to the server address specified in serv_addr.
	 * The last argument represents the size of the server address.
	 * If the connection succeeds, it returns 0 else it returns -1.
	 */
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
		printf("\nConnection Failed \n");
		return -1;
	}


	/* [C5]
	 * getchar prompts the user to enter any character to continue the execution.
	 */
	printf("Press any key to continue...\n");
	getchar();

	/* [C6]
	 * send call delivers the message through the connected socket.
	 * It uses the file descriptor sock for the destination information.
	 * hello is the actual data to be sent and the third argument is the size of the data.
	 * The last argument is the flags for the communication.
	 * On success, it returns the number of characters sent, on failure it returns -1.
	 */
	send(sock , hello , strlen(hello) , 0 );
	printf("Hello message sent\n");

	/* [C7]
	 * read is used to read the message from the other end of socket communication.
	 * It uses sock for the connection information and the data read is stored in buffer(second argument).
	 * The last argument indicates number of bytes to be read.
	 * On success, it returns number of bytes read, 0 if it is the end of the file, -1 on error.
	 */
	if (read( sock , buffer, 1024) < 0) {
		printf("\nRead from server failed\n");
		return -1;
	}
	printf("Message from a server: %s\n",buffer );
	return 0;
}
