#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>

#define PORT 5984
#define BUFF_SIZE 4096

int main(int argc, const char *argv[])
{
	int server_fd, new_socket;
	struct sockaddr_in address;
	int opt = 1;
	int addrlen = sizeof(address);
	char buffer[BUFF_SIZE] = {0};
	char *hello = "Hello from server";

	/* [S1]
	 * The socket function call creates an endpoint for communication.
	 * It takes three arguments domain, type and protocol.
	 * Domain specifies the communication domain in which the socket has to be created.
	 * Domain AF_INET indicates IPv4 Protocol.
	 * Type specifies the type of socket to be created.
	 * Type SOCK_STREAM provides sequential, bidirectional connection mode streams.
	 * Protocol value '0' represents the default protocol.
	 * It returns file descriptor on success, -1 on error. 
	 */
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	/* [S2]
	 * setsockopt function sets the option specified by the third argument at the protocol level specified by the second argument.
	 * It gets the socket information from the first argument(server_fd).
	 * SOL_SOCKET is mentioned to set option at socket level.
	 * The third argument here indicates that the rules used in validating addresses supplied to bind() should allow reuse of local addresses and ports.
	 * The last two arguments represents option value and its length.
	 * On success, it returns 0 and -1 on error.     
	 */
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
		       &opt, sizeof(opt))) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

	/* [S3]
	 * Assigning type, address and port to the address object.
	 * AF_INET represents IPv4 protocol and PORT is set to the object.
	 */
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons( PORT );

	/* [S4]
	 * bind function assigns the address specified by the address(second argument) to the socket referred to by the file descriptor server_fd(first argument).
	 * The last argument indicates the length of the address.
	 * On success it returns 0, -1 on error.   
	 */
	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

	/* [S5]
	 * listen marks the socket referred to by server_fd(first argument) that will be used to accept incoming connections.
	 * The second argument backlog indicates the maximum length to which the queue of the pending connections for the socket may grow.
	 * On success, it returns 0, -1 on error.     
	 */
	if (listen(server_fd, 3) < 0) {
		perror("listen");
		exit(EXIT_FAILURE);
	}

	/* [S6]
	 * accept system call is used to extract the first pending connection for the listening socket server_fd(first argument) and creates a new file descriptor new_socket.
	 * The second argument address is the address of the peer socket.
	 * The third argument indicates the size in bytes to contain the address.
	 * On success, it returns a non negative integer that is new_socket, -1 on error.
	 */
	if ((new_socket = accept(server_fd, (struct sockaddr *)&address,
				 (socklen_t*)&addrlen)) < 0) {
		perror("accept");
		exit(EXIT_FAILURE);
	}

	/* [S7]
	 * getchar prompts the user to enter any character to continue the execution.
	 */
	printf("Press any key to continue...\n");
	getchar();

	/* [S8]
	 * read call is used to read the message from the client.
	 * It uses new_sock for the connection information and the data read is stored in buffer(second argument).
	 * On success, it returns number of bytes read, 0 if it is the end of the file, -1 on error. 
	 */
	if (read( new_socket , buffer, 1024) < 0) {
		printf("\nRead from client failed\n");
		exit(EXIT_FAILURE);
	}
	printf("Message from a client: %s\n",buffer );
	
	/* [S9]
	 * send call delivers the message through the connected socket.
	 * It uses the file descriptor new_socket for the destination(client) information.
	 * hello is the data to be sent to the client and the third argument represents the size of the data to be sent.
	 * The last argument is the flags for the communication.
	 * On success, it returns number of characters sent to the client, on error it returns -1. 
	 */
	send(new_socket , hello , strlen(hello) , 0 );
	printf("Hello message sent\n");
	return 0;
}
