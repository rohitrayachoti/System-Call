#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/syscall.h>
#include <string.h>

int main(int argc, char* argv[]) {
	char* testStr = "";
	int increment = 0;
	int arg;

	while((arg = getopt(argc, argv, "s:k:")) != -1) {
		switch(arg) {
			case 's':
				testStr = malloc(strlen(optarg));
				strcpy(testStr, optarg);
				break;
			case 'k':
				increment = atoi(optarg);
				break;
			case '?':
				printf("Unknown Argument\n");
				break;
		}
	}
	
	int ret = syscall(335, testStr, increment);

	if(ret == 0) {
		printf("\nSystem call return value : %d\n\nsys_s2_encrypt executed properly\n", ret);
	}
	else {
		printf("\nSystem call return value : %d\n\nsys_s2_encrypt not executed as expected\n", ret);
	}
	return 0;
}
